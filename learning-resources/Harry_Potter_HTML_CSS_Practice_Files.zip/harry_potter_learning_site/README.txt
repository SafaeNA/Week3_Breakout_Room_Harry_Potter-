HARRY POTTER - THE MAGIC BEGINS
HTML + CSS beginner learning project

1. Open the harry_potter_learning_site folder in VS Code.
2. Open index.html with Live Server, or double-click index.html in File Explorer.
3. Keep index.html, style.css and the images folder together.
4. The 4 SVG images included here are original illustrative placeholders; replace them with properly sourced movie stills if your class permits.
5. The trailer uses a YouTube embed URL; video playback requires internet and YouTube permission.
6. This is an independent practice example, NOT your teammates' shared repository. Do not overwrite their project.
